# Sandaru's Power Electronics Portfolio

A static portfolio site hosted on **GitHub Pages** — no build step, no framework, no backend.

---

## Folder Structure

```
portfolio/
│
├── index.html            ← Home page
├── projects.html         ← All projects listing
├── about.html            ← About page
├── style.css             ← Full design system (edit colours/fonts here)
├── projects.js           ← Project data (ADD NEW PROJECTS HERE)
│
├── projects/             ← One HTML file per project
│   ├── buck-converter.html
│   ├── grid-inverter.html       ← copy from buck-converter.html
│   └── ac-thermal-control.html  ← copy from buck-converter.html
│
└── assets/
    └── projects/
        ├── buck-converter/
        │   ├── cover.png
        │   ├── step-response.png
        │   └── bode-plot.png
        ├── grid-inverter/
        │   └── cover.png
        └── ...
```

---

## Step-by-Step: First-Time Setup

### Step 1 — Create a GitHub Repository
1. Go to https://github.com/new
2. Name it **exactly**: `YOUR_USERNAME.github.io`
   (e.g. if your GitHub username is `sandaru-ee`, name it `sandaru-ee.github.io`)
3. Set it to **Public**
4. Click **Create repository**

### Step 2 — Upload Your Files
**Option A — GitHub Web UI (easiest to start):**
1. Open your new repository
2. Click **Add file → Upload files**
3. Drag the entire `portfolio/` folder contents into the upload box
4. Scroll down, write a commit message like `Initial portfolio upload`
5. Click **Commit changes**

**Option B — Git command line:**
```bash
cd portfolio
git init
git add .
git commit -m "Initial portfolio upload"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_USERNAME.github.io.git
git push -u origin main
```

### Step 3 — Enable GitHub Pages
1. Go to your repository → **Settings** tab
2. In the left sidebar, click **Pages**
3. Under **Source**, select branch: `main`, folder: `/ (root)`
4. Click **Save**
5. Wait 1-2 minutes, then visit: `https://YOUR_USERNAME.github.io`

That's it. Your site is live.

---

## How to Add a New Project

### Step 1 — Add entry to `projects.js`
Open `projects.js` and add a new object inside the `PROJECTS` array:

```js
{
  id: "flyback-converter",
  title: "Flyback Converter Design",
  summary: "Complete design of an isolated flyback converter with transformer modelling, RCD snubber design, and CCM/DCM boundary analysis.",
  image: "assets/projects/flyback/cover.png",
  video: null,
  tags: ["power-electronics", "simulation"],
  tools: ["QSpice", "MATLAB"],
  year: "2025",
  status: "complete",    // "complete" | "in-progress" | "archived"
  featured: false,       // set true to show on home page
  link: "projects/flyback-converter.html",
  github: "https://github.com/YOUR_USERNAME/flyback-converter"
}
```

### Step 2 — Create the project page
1. Copy `projects/buck-converter.html` to `projects/flyback-converter.html`
2. Edit the title, subtitle, tags, derivation sections, and figures
3. Update the "Next Project" link at the bottom

### Step 3 — Add images/videos
Put them in `assets/projects/flyback/`:
- `cover.png` — used as the card thumbnail (ideal: 800×500px)
- Any other figures: name them descriptively (e.g. `step-response.png`, `bode.png`)

### Step 4 — Push to GitHub
```bash
git add .
git commit -m "Add flyback converter project"
git push
```
GitHub Pages updates within ~30 seconds.

---

## Writing Math (LaTeX)

MathJax is included on every page. Use standard LaTeX notation:

**Inline:** `$G_{vd}(s)$` — renders inside text

**Display (centred block):**
```
$$G_{vd}(s) = \frac{V_{in}}{LC} \cdot \frac{1}{s^2 + \frac{s}{RC} + \frac{1}{LC}}$$
```

**Aligned equations:**
```
$$\begin{align}
  \dot{i}_L &= -\frac{v_C}{L} + \frac{D \cdot V_{in}}{L} \\
  \dot{v}_C &= \frac{i_L}{C} - \frac{v_C}{RC}
\end{align}$$
```

---

## Adding Images

```html
<figure class="proj-figure">
  <img src="../assets/projects/your-project/plot.png" alt="Description" />
  <figcaption>Fig. 1 — Your caption here.</figcaption>
</figure>
```

---

## Adding Videos

Replace the `<img>` cover tag with:
```html
<video controls class="proj-cover-img">
  <source src="../assets/projects/your-project/demo.mp4" type="video/mp4" />
</video>
```

For inline demo sections, uncomment the video section in the project template.

Keep videos under **25 MB** for fast loading (GitHub has a 100MB file limit).
For large videos, upload to YouTube and embed with:
```html
<div class="proj-video-wrap">
  <iframe width="100%" height="400"
    src="https://www.youtube.com/embed/YOUR_VIDEO_ID"
    frameborder="0" allowfullscreen>
  </iframe>
</div>
```

---

## Customising the Site

### Change your name / links
Search for `YOUR_USERNAME` and `YOUR_EMAIL` across all files and replace them.

### Change colours
Open `style.css` and edit the `:root` variables at the top:
```css
:root {
  --navy:  #0a0e1a;   /* page background */
  --amber: #f59e0b;   /* accent colour */
  --cyan:  #38bdf8;   /* tool pills */
  ...
}
```

### Add a custom domain (optional)
1. Buy a domain (e.g. `sandaru.dev`)
2. In GitHub Pages settings → add your custom domain
3. Create a `CNAME` file at the root of your repo containing just: `sandaru.dev`

---

## Maintaining the Site

| Task | Command |
|------|---------|
| Preview locally | Open `index.html` in a browser (or use VS Code Live Server extension) |
| Push changes | `git add . && git commit -m "message" && git push` |
| Check deploy status | GitHub repo → Actions tab |
